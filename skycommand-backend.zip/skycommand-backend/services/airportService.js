const { mockFlights } = require('./mockFlights');

// Real-world coordinates for the airports referenced in mockFlights.js.
// Small, hand-maintained table — swap for a proper airports dataset
// (e.g. OpenFlights airports.csv) if the flight roster grows.
const KNOWN_AIRPORT_COORDS = {
  LHR: { latitude: 51.4700, longitude: -0.4543 },
  JFK: { latitude: 40.6413, longitude: -73.7781 },
  CDG: { latitude: 49.0097, longitude: 2.5479 },
  DXB: { latitude: 25.2532, longitude: 55.3657 },
  HND: { latitude: 35.5494, longitude: 139.7798 },
  SYD: { latitude: -33.9399, longitude: 151.1753 },
  ATL: { latitude: 33.6407, longitude: -84.4277 },
  LAX: { latitude: 33.9416, longitude: -118.4085 },
};

// Build a de-duplicated airport list from every departure/arrival in mockFlights.
// This keeps the airport list consistent with whatever flights are being shown,
// rather than maintaining a second, unrelated dataset that can drift out of sync.
function getAirports() {
  const airportMap = new Map();

  mockFlights.forEach((flight) => {
    [flight.departure, flight.arrival].forEach((airport) => {
      if (!airport || airportMap.has(airport.iata)) return;
      const coords = KNOWN_AIRPORT_COORDS[airport.iata] || {};
      airportMap.set(airport.iata, {
        iata: airport.iata,
        name: airport.name,
        country: airport.country,
        latitude: coords.latitude ?? null,
        longitude: coords.longitude ?? null,
      });
    });
  });

  return Array.from(airportMap.values());
}

module.exports = { getAirports };
