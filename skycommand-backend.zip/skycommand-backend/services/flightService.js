const openskySkyService = require('./openskySkyService');
const { mockFlights } = require('./mockFlights');

async function getLiveFlights() {
  try {
    // Try to get real flights from OpenSky
    return await openskySkyService.getLiveFlights();
  } catch (error) {
    console.log('[FlightService] Error fetching Amadeus data, using mock data:', error.message);
    // Fallback to mock data
    return mockFlights.map((flight) => ({
      id: flight.id,
      flightCode: flight.flightCode,
      airline: flight.airline,
      airlineCode: flight.flightCode.split('-')[0],
      country: flight.departure?.country || null,
      departure: flight.departure,
      arrival: flight.arrival,
      currentAltitude: flight.currentAltitude,
      status: flight.status,
      progress: flight.progress,
      aircraftType: flight.aircraftType,
      departureTime: flight.departureTime,
      estimatedArrival: flight.estimatedArrival,
      lastUpdated: flight.lastUpdated,
      currentPosition: flight.currentPosition
    }));
  }
}

async function getFlightByCode(flightCode) {
  const flights = await getLiveFlights();
  return flights.find((flight) => flight.flightCode === flightCode) || null;
}

async function searchFlights(filters = {}) {
  const flights = await getLiveFlights();
  
  const normalized = {
    flightCode: filters.flightCode?.toLowerCase(),
    departure: filters.departure?.toUpperCase(),
    arrival: filters.arrival?.toUpperCase(),
    status: filters.status?.toUpperCase(),
    limit: Number(filters.limit) || 50,
    offset: Number(filters.offset) || 0
  };

  const matches = flights.filter((flight) => {
    if (normalized.flightCode && !flight.flightCode.toLowerCase().includes(normalized.flightCode)) {
      return false;
    }

    if (normalized.departure && flight.departure.iata !== normalized.departure) {
      return false;
    }

    if (normalized.arrival && flight.arrival.iata !== normalized.arrival) {
      return false;
    }

    if (normalized.status && flight.status !== normalized.status) {
      return false;
    }

    return true;
  });

  return {
    total: matches.length,
    limit: normalized.limit,
    offset: normalized.offset,
    data: matches.slice(normalized.offset, normalized.offset + normalized.limit)
  };
}

async function getAnalyticsStats() {
  const flights = await getLiveFlights();

  const delayedFlights = flights.filter((flight) => flight.status === 'Delayed' || flight.status === 'DELAYED').length;
  const inFlightCount = flights.filter((flight) => ['IN-FLIGHT', 'ACTIVE'].includes(flight.status)).length;
  const averageAltitude = flights.length > 0 
    ? Math.round(flights.reduce((sum, flight) => sum + flight.currentAltitude, 0) / flights.length)
    : 0;
  const averageSpeed = flights.length > 0
    ? Math.round(flights.reduce((sum, flight) => sum + (flight.currentPosition?.speed || 0), 0) / flights.length)
    : 0;

  // Carrier share: group by airline, count flights per carrier.
  const carrierMap = new Map();
  flights.forEach((flight) => {
    if (!flight.airline) return;
    const key = flight.airlineCode || flight.airline;
    const existing = carrierMap.get(key);
    if (existing) {
      existing.count += 1;
    } else {
      carrierMap.set(key, { code: key, name: flight.airline, count: 1 });
    }
  });

  // Sector load: group by departure country, flag load level by flight count.
  const countryMap = new Map();
  flights.forEach((flight) => {
    const country = flight.departure?.country;
    if (!country) return;
    countryMap.set(country, (countryMap.get(country) || 0) + 1);
  });
  const sectorLoad = Array.from(countryMap.entries()).map(([country, count]) => ({
    country,
    count,
    status: count >= 2 ? 'HIGH LOAD' : count === 1 ? 'NOMINAL' : 'LOW LOAD',
    color: count >= 2 ? 'var(--tertiary-fixed-dim)' : 'var(--secondary-fixed-dim)',
  }));

  const onTimePercentage = flights.length > 0
    ? Number((((flights.length - delayedFlights) / flights.length) * 100).toFixed(1))
    : 100;

  return {
    totalFlights24h: Math.floor(Math.random() * 50000) + 10000,
    activeFlights: flights.length,
    delayedFlights,
    cancelledFlights: 0,
    onTimePercentage,
    averageAltitude,
    averageSpeed,
    activeSectors: countryMap.size,
    networkLatency: '12ms',
    flightStatus: {
      inFlight: inFlightCount,
      delayed: delayedFlights,
      total: flights.length,
    },
    carrierShare: Array.from(carrierMap.values()),
    sectorLoad,
    networkHealth: {
      score: Math.round(onTimePercentage),
      status: onTimePercentage >= 90 ? 'OPTIMAL' : onTimePercentage >= 75 ? 'DEGRADED' : 'CRITICAL',
    },
  };
}

function getSectorById(sectorId) {
  const flights = mockFlights.filter((flight) => flight.sectorId === sectorId);

  return {
    sectorId,
    sectorName: sectorId === 'SECTOR_01' ? 'Atlantic Corridor' : sectorId === 'SECTOR_02' ? 'European Transit' : 'Pacific Gateway',
    activeFlights: flights.filter((flight) => ['IN-FLIGHT', 'ACTIVE'].includes(flight.status)).length,
    avgDensity: Number((flights.length * 3.2).toFixed(1)),
    flights
  };
}

module.exports = {
  getLiveFlights,
  getFlightByCode,
  searchFlights,
  getAnalyticsStats,
  getSectorById
};
