import fs from "fs";
import path from "path";
import csv from "csv-parser";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function getMROHubs() {
  return new Promise((resolve, reject) => {
    const results = [];

    fs.createReadStream(
      path.join(__dirname, "../data/mro_hubs.csv")
    )
      .pipe(csv())
      .on("data", (data) => {
        results.push({
          ...data,
          latitude: Number(data.latitude),
          longitude: Number(data.longitude),
          hangars: Number(data.hangars),
          annual_capacity: Number(data.annual_capacity),
        });
      })
      .on("end", () => resolve(results))
      .on("error", reject);
  });
}