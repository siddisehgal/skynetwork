import express from "express";
import { getMROHubs } from "../services/mroService.js";

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const hubs = await getMROHubs();
    res.json(hubs);
  } catch (err) {
    console.error(err);
    res.status(500).json({
      error: "Unable to load MRO hubs",
    });
  }
});

export default router;