const express = require('express');
const { getAirports } = require('../services/airportService');

const router = express.Router();

router.get('/', (req, res) => {
  try {
    const data = getAirports();
    res.json({
      success: true,
      data,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('[Airports Route] Error:', error.message);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch airports',
      error: error.message
    });
  }
});

module.exports = router;
