const airports = [
  { icao: 'EGLL', iata: 'LHR', name: 'London Heathrow Airport', country: 'United Kingdom', latitude: 51.4706, longitude: -0.4619 },
  { icao: 'LFPG', iata: 'CDG', name: 'Paris Charles de Gaulle Airport', country: 'France', latitude: 49.0097, longitude: 2.5479 },
  { icao: 'KJFK', iata: 'JFK', name: 'John F. Kennedy International Airport', country: 'United States', latitude: 40.6413, longitude: -73.7781 },
  { icao: 'KATL', iata: 'ATL', name: 'Hartsfield-Jackson Atlanta International Airport', country: 'United States', latitude: 33.6407, longitude: -84.4277 },
  { icao: 'KLAX', iata: 'LAX', name: 'Los Angeles International Airport', country: 'United States', latitude: 33.9416, longitude: -118.4085 },
  { icao: 'OMDB', iata: 'DXB', name: 'Dubai International Airport', country: 'United Arab Emirates', latitude: 25.2532, longitude: 55.3657 },
  { icao: 'WSSS', iata: 'SIN', name: 'Singapore Changi Airport', country: 'Singapore', latitude: 1.3644, longitude: 103.9915 },
  { icao: 'RJTT', iata: 'HND', name: 'Tokyo Haneda Airport', country: 'Japan', latitude: 35.5494, longitude: 139.7798 },
  { icao: 'YSSY', iata: 'SYD', name: 'Sydney Kingsford Smith Airport', country: 'Australia', latitude: -33.9399, longitude: 151.1753 },
  { icao: 'EDDF', iata: 'FRA', name: 'Frankfurt Airport', country: 'Germany', latitude: 50.0379, longitude: 8.5622 },
  { icao: 'EHAM', iata: 'AMS', name: 'Amsterdam Airport Schiphol', country: 'Netherlands', latitude: 52.3105, longitude: 4.7683 },
  { icao: 'VIDP', iata: 'DEL', name: 'Indira Gandhi International Airport', country: 'India', latitude: 28.5562, longitude: 77.1 },
];

module.exports = { airports };
