const { getFlightByCode } = require('../services/flightService');

const POLL_INTERVAL_MS = 15000;

function registerFlightSockets(io) {
  io.on('connection', (socket) => {
    socket.on('join-flight', (flightCode) => {
      socket.join(`flight:${flightCode}`);
    });

    socket.on('leave-flight', (flightCode) => {
      socket.leave(`flight:${flightCode}`);
    });

    socket.on('disconnect', () => {
      // No-op for now; hook for future cleanup.
    });
  });

  // Push updates to any room that has at least one subscriber.
  setInterval(async () => {
    const rooms = io.sockets.adapter.rooms;
    for (const roomName of rooms.keys()) {
      if (!roomName.startsWith('flight:')) continue;

      const flightCode = roomName.slice('flight:'.length);
      try {
        const flight = await getFlightByCode(flightCode);
        if (flight) {
          io.to(roomName).emit('flight-update', flight);
        }
      } catch (error) {
        console.error(`[Sockets] Failed to push update for ${flightCode}:`, error.message);
      }
    }
  }, POLL_INTERVAL_MS);
}

module.exports = { registerFlightSockets };
